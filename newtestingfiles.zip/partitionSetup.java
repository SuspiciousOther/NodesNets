import java.util.ArrayList;


public class partitionSetup {
	
	public ArrayList<Nodes> partition0;
	public ArrayList<Nodes> partition1;
	
  	public partitionSetup() {
  		partition0 = new ArrayList<Nodes>();
  		partition1 = new ArrayList<Nodes>();
    }
  	
    public Nodes getNodeAtIndex(ArrayList<Nodes> partition, int index) {
        return partition.get(index);
    }
    public void addNode(String nodeNameC, float DC , float IC , float EC, double XC, double YC, int CanvasX) {
    	if(XC < (CanvasX-(CanvasX/2)-25)){
    		partition0.add(new Nodes(nodeNameC, DC, IC, EC, XC, YC));
    	}
    	else{
    		partition1.add(new Nodes(nodeNameC, DC, IC, EC, XC, YC));
    	}
    }
    
    public void addNode(Nodes myNode,double newX, double newY, int Section) {
    	
    	if(Section == 0){
    		partition0.add(new Nodes(myNode.getNodeName(), myNode.getD() , myNode.getI() , myNode.getE() , newX , newY ));
    	}
    	else{
    		partition1.add(new Nodes(myNode.getNodeName(), myNode.getD() , myNode.getI() , myNode.getE() , newX , newY ));
    	}
    }    
    
    public void removeNode(Nodes myNode, partitionSetup partition, ArrayList<Nodes> partitionArea){
    	for (int index = 0; index < partitionArea.size(); index++){
    		 if(partition.getNodeAtIndex(partitionArea, index).equals(myNode)){
    			 partitionArea.remove(index);
    		 }
    	}
    }
    
    public String returnPartition(ArrayList<Nodes> partition, String nameOfNode){ //always pass in partition 1
    	if (partition.contains(nameOfNode)){
    		return "p1";
    	}
    	else{
    		return "p2";
    	}
    }

}
