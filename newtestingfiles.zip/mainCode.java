/*
 * mainCode.c
 *
 *  Created on: Feb 12, 2020
 *      Author: smith
 */


import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.*;

import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.io.File; 
import java.util.ArrayList;
import java.util.Scanner;


public class mainCode extends JFrame{
   
   private static final double CanvasX = 800;
   private static final double CanvasY = 600;
   
    public static void plotNode(Graphics g2, Nodes myArrayOfNodes){
      double x = myArrayOfNodes.getX() * (CanvasX-100) + 20;
      double y = myArrayOfNodes.getY() * (CanvasY-100) + 20;
      g2.setColor(new Color((int)(Math.random() * 255), (int)(Math.random()* 255), (int)(Math.random()* 255))); 
      ((Graphics2D) g2).draw(new Ellipse2D.Double((x),(y), 3, 3));
      ((Graphics2D) g2).fill(new Ellipse2D.Double((x),(y), 3, 3));
   }
    
    
    public static void plotEdges(Graphics g2, Edges myEdge, partitionSetup partition, arrayOfNodes myArrayOfNodes){
      g2.setColor(new Color(0, 0, 0));
      System.out.println(myEdge.toString());
      System.out.println(myEdge.size());
      if (myEdge.size() > 2){
         
         System.out.println("Plotted");
         int k = myArrayOfNodes.size();
         ArrayList<Double> x1 = new ArrayList<>();
         ArrayList<Double> y1 = new ArrayList<>();
         double x2 = 0;
         double y2 = 0;
         for (int l = 0; l < k; l++){
            int p = myEdge.size();
               for (int f = 0; f < p; f++){
                  if (myArrayOfNodes.getNodeAtIndex(l).getNodeName().equals(myEdge.getEdgeAtIndex(f))){
                     x1.add(myArrayOfNodes.getNodeAtIndex(l).getX()* (CanvasX-100));
                     y1.add(myArrayOfNodes.getNodeAtIndex(l).getY()* (CanvasY-100));
                     x2 += myArrayOfNodes.getNodeAtIndex(l).getX()* (CanvasX-100);
                     y2 += myArrayOfNodes.getNodeAtIndex(l).getY()* (CanvasY-100);
                  }
               }
         }
         x2 = x2/x1.size();
         y2 = y2/x1.size();
         for (int j = 0; j < x1.size(); j++){
            ((Graphics2D) g2).draw(new Line2D.Double(x1.get(j)+20,y1.get(j)+20, x2+20, y2+20));
         }
         
      }
      else{

         int k = myArrayOfNodes.size();
         double x1 = 0,y1 = 0,x2 = 0,y2 = 0;
         for (int l = 0; l < k; l++){
            if (myArrayOfNodes.getNodeAtIndex(l).getNodeName().equals(myEdge.getEdgeAtIndex(0))){
               x1 = myArrayOfNodes.getNodeAtIndex(l).getX()* (CanvasX-100);
               y1 = myArrayOfNodes.getNodeAtIndex(l).getY()* (CanvasY-100);
            }
            if (myArrayOfNodes.getNodeAtIndex(l).getNodeName().equals(myEdge.getEdgeAtIndex(1))){
               x2 = myArrayOfNodes.getNodeAtIndex(l).getX()* (CanvasX-100);
               y2 = myArrayOfNodes.getNodeAtIndex(l).getY()* (CanvasY-100);
            }
         }
         ((Graphics2D) g2).draw(new Line2D.Double(x1+20,y1+20, x2+20, y2+20));
      }
   }    
    
    public static void drawPartitons(Graphics g2){
      g2.setColor(new Color(127, 137, 153)); 
      ((Graphics2D) g2).draw(new Rectangle2D.Double((CanvasX-(CanvasX - 10)),10, (CanvasX-(CanvasX/2)-50), CanvasY-60));
      ((Graphics2D) g2).draw(new Rectangle2D.Double((CanvasX-(CanvasX/2 + 10)),10, (CanvasX-(CanvasX/2)-50), CanvasY-60));
      ((Graphics2D) g2).draw(new Line2D.Double((CanvasX-(CanvasX/2)-25),5, (CanvasX-(CanvasX/2)-25), CanvasY-45));
   }

    public static void main(String[] args) throws Exception  
     { 
      
      
      new mainCode();
      arrayOfNodes nodesArr = new arrayOfNodes();
      File file1 = new File("F:\\Java Workspaces\\PhysDesignA1\\Files\\spp_N193_E227_R11_153.nodes.txt");
      File file2 = new File("F:\\Java Workspaces\\PhysDesignA1\\Files\\spp_N193_E227_R11_153.nets.txt");   
      Scanner sc1 = new Scanner(file1); 
      Scanner sc2 = new Scanner(file2); 
      String s = new String();
      
      int index = 0;
       while (sc1.hasNextLine()){
         s = sc1.nextLine();
            if ( index > 6 ){
            nodesArr.addNode(s, 0, 0, 0, Math.random(), Math.random());
            }
            index++;
       } 
       
       //System.out.println(nodesArr.getCustArr());
       ArrayList<String> nodesArr2 = new ArrayList<String>();
       arrayOfEdges EdgesArr = new arrayOfEdges();
      index = 0;
      int j = 0; //Net Degree
      int k = 0;
      
      
       while (sc2.hasNextLine()){
         s = sc2.nextLine();
            if ( index > 5){
            if (s.length() > 11){
               j = Integer.parseInt(s.substring(12));
               //System.out.println(s.substring(12));
               //System.out.println("J = " + j);
               nodesArr2 = new ArrayList<String>();
               k = 0;
            }
            else{
               if (k < j){
                  nodesArr2.add(s.substring(0,s.length()-2));
                  //System.out.println(nodesArr2);
                  k++;
                  if (k == j){
                     EdgesArr.addEdge(nodesArr2, 1);
                     //System.out.println(EdgesArr.getCustArr());
                  }
               }
            }
            }
            index++;
       }
       
       //Phase 1: Creating Initial Partition 
       partitionSetup partition = new partitionSetup();
       for (int l = 0; l < nodesArr.size(); l++){
         if ((l & 1) == 0){
            partition.addNode(nodesArr.getNodeAtIndex(l),nodesArr.getNodeAtIndex(l).getX(), nodesArr.getNodeAtIndex(l).getY(), 0);
         }
         else{
            partition.addNode(nodesArr.getNodeAtIndex(l),nodesArr.getNodeAtIndex(l).getX(), nodesArr.getNodeAtIndex(l).getY(), 1);
         }
       }
       
       
       //End Phase 1
      
      
      //Phase 2: Creating Optimized Partition 
      
      partitionSetup optimizedPartition = new partitionSetup(partition);                     //Create Deep Copy of Old Partition
      klAlg myKl = new klAlg();                                                              //Create new klAlgorithm Object
      
      for (int l = 0; l<optimizedPartition.partition0.size(); l++){                          //Calculate Parameters for partition0
         double myParameterArray[3] = myKl.getNodeParameters(optimizedPartition, optimizedPartition.getNodeAtIndex(partition0, l), EdgesArr)
         optimizedPartition.getNodeAtIndex(partition0, l).setI(myParameterArray[0]);
         optimizedPartition.getNodeAtIndex(partition0, l).setE(myParameterArray[1]);
         optimizedPartition.getNodeAtIndex(partition0, l).setD(myParameterArray[2]);
      }
      
      for (int l = 0; l<optimizedPartition.partition1.size(); l++){                          //Calculate Parameters for partition1
         double myParameterArray[3] = myKl.getNodeParameters(optimizedPartition, optimizedPartition.getNodeAtIndex(partition1, l), EdgesArr)
         optimizedPartition.getNodeAtIndex(partition1, l).setI(myParameterArray[0]);
         optimizedPartition.getNodeAtIndex(partition1, l).setE(myParameterArray[1]);
         optimizedPartition.getNodeAtIndex(partition1, l).setD(myParameterArray[2]);
      }
                
      partitionSetup iteratedPartition = new partitionSetup(partition);                      //Create Deep Copy of Old Partition for nodes not optimized
      ArrayList<Double> gainIteration = new ArrayList<>();                                   //How much gain happened at the iteration
      arrayOfNodes gainNodesIteration = new arrayOfNodes();                                  //Which nodes were swapped
      double storeImprovement = 0;
      
      //Pseudo Code
      
      for (var i = 0; i < Object.keys(design.groupA).length; i++) { //groupA has same or 1 less element then B
         
         //Search for best pair
         var bestPair = null; //[a,b,gain]
         unlockedA.map ( a => {
            unlockedB.map( b => {
               var g = design.groupA[a].D + design.groupB[b].D - 2 * getCost(edges,a,b);
//             console.log('    ==> Exchange '+a+' and '+b+' ==> Gain = '+g);
               if (!bestPair || bestPair[2] < g)
                  bestPair = [a,b,g];
            } );
         } );
         
         //Now we have the best pair, lock and record
         var bestA = bestPair[0], bestB = bestPair[1], bestGain = bestPair[2];
         unlockedA = unlockedA.filter( x => {return x != bestA} );
         unlockedB = unlockedB.filter( x => {return x != bestB} );
         
         gAcc += bestGain;
         gainStep.push(gAcc);
         gainStepNodes.push([bestA,bestB]);
         
         //Exchange
         swap(design,bestA,bestB);
         console.log('  ['+i+'] Best pair: ',lo(bestPair),'Gain = '+gAcc,'Aft swap: ',lo(design));
         
         //Update D value of unclocked nodes
         unlockedA.map( key => {
            var die = getNodeDIE(key,design,edges);
            design.groupA[key].D = die[0];
            design.groupA[key].I = die[1];
            design.groupA[key].E = die[2];
         } );
         unlockedB.map( key => {
            var die = getNodeDIE(key,design,edges);
            design.groupB[key].D = die[0];
            design.groupB[key].I = die[1];
            design.groupB[key].E = die[2];
         } );
         
      }
      
      //Find which step that gain is max
      var gMax = Math.max(...gainStep);
      var gMaxStep = gainStep.findIndex( x => {return x == gMax} );
      for (var i = 0; i <= gMaxStep; i++) {
         swap(currentDesign,gainStepNodes[i][0],gainStepNodes[i][1]);
      }
      
      console.log('Design '+(++workloop)+': ',lo(currentDesign),'Gain = '+gMax);
      
      //Greedy
      if (gMax > 0 && workloop < maxTryTimes) {
         setTimeout(kl,animationSpeed);
         bestDesign = lo(currentDesign);
         draw(currentDesign,edges);
      }
      else {
         console.log('Done! Best result shown below:');
         console.log(lo(bestDesign));
         alert('Done!');
      }
   }
   
   setTimeout(kl,animationSpeed);
      
      //End Pseudo Code
      
      
      
      
      
      
      
      
      //End Phase 2
      
       
       JFrame frame = new JFrame();     
       frame.add(new JPanel()
       {
         
         public void paint(Graphics g)
         {
           super.paint(g);
           Graphics2D g2 = (Graphics2D) g;
          int k = nodesArr.size();
          for (int l = 0; l<k; l++){
            plotNode(g2, nodesArr.getNodeAtIndex(l));
          }
          
          k = EdgesArr.size();
          for (int l = 0; l<k; l++){
            plotEdges(g2, EdgesArr.getEdgeAtIndex(l), partition, nodesArr);
          }           
          
          drawPartitons(g2);
         }
       });
      frame.setSize((int)CanvasX-30, (int)CanvasY); 
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);    
      frame.repaint();
       
       //System.out.println(EdgesArr.getCustArr());
     }   
    
}

