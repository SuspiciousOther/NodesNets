public class klAlg {
	private double cost = 0;
	public double[] getNodeParameters(partitionSetup partition, Nodes node, arrayOfEdges arrEdges){
	   double D = 0, I = 0, E = 0;
		for (int i = 0; i < partition.partition0.size(); i++){
			if (partition.partition0.contains(node.getNodeName())){
				if (!node.getNodeName().equals(partition.getNodeAtIndex(partition.partition0,i).getNodeName())){ //if the nodes are not equal
				   I += (node.getI() + getCost(node.getNodeName(),partition.getNodeAtIndex(partition.partition0,i).getNodeName(), arrEdges));
				}
			}
			else {
				if (!node.getNodeName().equals(partition.getNodeAtIndex(partition.partition0,i).getNodeName())){ //if the nodes are not equal
				   E += (node.getE() + getCost(node.getNodeName(),partition.getNodeAtIndex(partition.partition0,i).getNodeName(), arrEdges));
				}
			}
			if (partition.partition1.contains(node.getNodeName())){
				if (!node.getNodeName().equals(partition.getNodeAtIndex(partition.partition1,i).getNodeName())){ //if the nodes are not equal
				   I += (node.getI() + getCost(node.getNodeName(),partition.getNodeAtIndex(partition.partition1,i).getNodeName(), arrEdges));
				}
			}
			else{
				if (!node.getNodeName().equals(partition.getNodeAtIndex(partition.partition1,i).getNodeName())){ //if the nodes are not equal
				   E += (node.getE() + getCost(node.getNodeName(),partition.getNodeAtIndex(partition.partition1,i).getNodeName(), arrEdges));
				}
			}
		}
		D = E - I;
		return(I, E, D)
	}
	
	public boolean checkConnection(partitionSetup partition, Edges myEdge){
		boolean flag_p1 = false;
		boolean flag_p2 = false;
		for (int i = 0; i< myEdge.size(); i++){
			if (partition.returnPartition(partition.partition0, myEdge.getEdgeAtIndex(i)).equals("p1")){
				flag_p1 = true;
			}
			if (partition.returnPartition(partition.partition0, myEdge.getEdgeAtIndex(i)).equals("p2")){
				flag_p2 = true;
			}
			if (flag_p1 && flag_p2) {break;}
		}
		return (flag_p1 && flag_p2);
	}
	
	public void interchange(Nodes node1, Nodes node2, partitionSetup partition){
		double newX1 = node2.getX();
		double newX2 = node1.getX();
		double newY1 = node2.getY();
		double newY2 = node1.getY();		
		
		partition.removeNode(node1, partition, partition.partition0);
		partition.removeNode(node2, partition, partition.partition1);
		partition.addNode(node1,newX1, newY1, 1);
		partition.addNode(node2,newX2, newY2, 0);
	}
	
	public double getCost(String nodeOne, String nodeTwo, arrayOfEdges arrayEdges){
		cost = 0;
		for (int i = 0; i < arrayEdges.size(); i++){
			if (arrayEdges.getEdgeAtIndex(i).getEdge().contains(nodeOne) && arrayEdges.getEdgeAtIndex(i).getEdge().contains(nodeTwo)){
				cost += arrayEdges.getEdgeAtIndex(i).getWeight() / (arrayEdges.size()-1);
			}
		}
		return cost;
	}
	
}
